/**************************************************************/
  // fbR_manager.js
  // 
  /**************************************************************/
MODULENAME = "fbR_manager.js";
console.log('%c' + MODULENAME + ': ', 'color: blue;');

const DETAILS = "userDetails";
const LOBBY   = "lobby"
const KASCORE = "userScores/ka"
var userDetails = {};
var dbData;

  /**************************************************************/
  // fbR_initialise()
  // Called by setup
  // Initialize firebase
  // Input:  n/a
  // Return: n/a
  /**************************************************************/
function fbR_initialise() {
  console.log('%cfbR_initialise: ', 'color: brown;');

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
    const FIREBASECONFIG = {
      apiKey: "AIzaSyAn0HZ-1GL7I7-UUawRXQpjQcJM0cJ_LIk",
      authDomain: "comp-2024-fuard-abdullahi.firebaseapp.com",
      databaseURL: "https://comp-2024-fuard-abdullahi-default-rtdb.firebaseio.com",
      projectId: "comp-2024-fuard-abdullahi",
      storageBucket: "comp-2024-fuard-abdullahi.appspot.com",
      messagingSenderId: "1008924006485",
      appId: "1:1008924006485:web:8bd3374d298abb8818dcdc",
      measurementId: "G-RFYM3C7FNY"
    };
    
    
  // Check if firebase already initialised
  if (!firebase.apps.length) {
    firebase.initializeApp(FIREBASECONFIG);
    database = firebase.database();
  }
}



  /**************************************************************/
  // fbR_getValue()
  // Input:  User's imformation
  // Return: Saves user's uid, email, name and photoURL
  /**************************************************************/
  function fbR_getValue(){
    
  }

  /**************************************************************/
  // fbR_procLogin()
  // Input:  User's imformation
  // Return: Saves user's uid, email, name and photoURL
  /**************************************************************/
function fbR_procLogin(_loginStatus, _user, _save) {
  console.log("fbR_procLogin");
  
  _save.uid             = _user.uid;
  _save.email           = _user.email;
  _save.displayName     = _user.displayName;
  _save.photoURL        = _user.photoURL;
  _save.gameName        = _user.gameName;

  sessionStorage.setItem("uid", _user.uid);
  sessionStorage.setItem("email", _user.email);
  sessionStorage.setItem("displayName", _user.displayName);
  sessionStorage.setItem("photoURL", _user.photoURL);
  sessionStorage.setItem("gameName", _user.gameName);

  fb_readRec(DETAILS, userDetails.uid, userDetails, fbR_procReadUD);
}

  /**************************************************************/
  // fbR_procWUD()
  // Input:  User's imformation
  // Return: Saves user's uid, email, name and photoURL
  /**************************************************************/
function fbR_procWUD(_path, _key, _data, _error){
  console.log('%cfb_procWUD: path= '+_path+
              ' error= '+_error, 'color: brown;')

  if(_error){
    writeStatus = "failed...";
    console.log('%cfb_procWUD: writeStatus= '+ writeStatus,
               'color: red');
    console.error(_error);
  }
  else{
    writeStatus = 'OK';
    console.log('%cfb_procWUD: writeStatus= '+ writeStatus,
               'color: black');
    window.location = "/html/gs.html";
  }
}

  /**************************************************************/
  // fbR_procReadAllUD(_path, _snapshot, _save, _error)
  // Input:  User's imformation
  // Return: Saves user's uid, email, displayName and photoURL
  /**************************************************************/
function fbR_procReadAllUD(_path, _snapshot, _save, _error){
  console.log('%cfb_procReadAllUD: path='+_path,
             'color: brown');

  if(_error == null){
    dbData = _snapshot.val();
    if(dbData == null){
      readStatus = 'no records';
    }
    else{
      readStatus = 'OK';
      var dbKeys = Object.keys(dbData);
      console.log(dbKeys);
      for(i=0; i < dbKeys.length; i++){
        var k = dbKeys[i];
        _save.push({
          displayName: dbData[k].displayName,
          score: dbData[k].score
        });
      }
    }
  }
  else{
    // There was an error
    readStatus = 'error';
    console.log('%c'+_error, 'color: red;');
  }
}

/**************************************************************/
// fbR_procReadUD(_path, _key, _snapshot, _save, _error)
// Check if we have the user's info
// Input:  User's imformation
// Return: 
/**************************************************************/
function fbR_procReadUD(_path, _key, _snapshot, _save, _error){
  console.log('%cfb_procReadUD: path= '+ _path + 
             ' key= '+ _key, 'color: brown');

  if(_error == null){
    dbData = _snapshot.val();
    if(dbData != null){
      // User already registered
      sessionStorage.setItem("gameName", _save.gameName);
      readStatus = 'OK';
      window.location = "/html/gs.html";
    }
    else{
      readStatus = 'no record';
      // User NOT registered
      window.location = "/html/reg.html";
    }
  }
  else{
    readStatus = 'error';
    console.log('%c' + _error, 'color: red;');
  }
}

/**************************************************************/
// fbR_procP2Join(_path, _key, _snapshot, _save, _error)
// Check if we have the user's info
// Input:  User's imformation
// Return: 
/**************************************************************/
function fbR_procP2Join(_path, _key, _snapshot, _save, _error){
  console.log('%c fbR_procP2Join: path= '+ _path + 
             ' key= '+ _key, 'color: brown');

  if(_error == null){
    dbData = _snapshot.val();
        if (dbData === null) {
        console.error('fb_readon: path/user:  ' + _path + '/' + _key +
        " no record");
    }
    else if(dbData == true) {
          console.log('fb_readon: path/user:  ' + _path + '/' + _key +
          " player 2 joined");
          // cancel the readon here
          database.ref(_path + '/' + _key).off();
    }
    else {
          console.log('fb_readon: path/user:  ' + _path + '/' + _key +
          " still waiting");
    }
  }
  else{
    readStatus = 'error';
    console.error('%c' + _error, 'color: red;');
  }
};


/**************************************************************/
// fbR_procReadScores()
// Input:  User's imformation
// Return: Saves user's uid, email, displayName and photoURL
/**************************************************************/
function fbR_procReadScores(_path, _key, _snapshot, _save, _error){
  console.log('%cfb_procReadScores: path= '+_path+
             ' key= '+_key, 'color: brown;');

  if(_error == null){
    dbData = _snapshot.val();
    if(dbData != null){
      _save.score = dbData.score;
      readStatus = 'OK';
    }
    else{
      readStatus = 'no record';
    }
  }
  else{
    // There was an error
    readStatus = 'error';
    console.log('%c' + _error, 'color: red;');
  }
}

  /**************************************************************/
  // fbR_procReadAdmin()
  // Input:  User's imformation
  // Return: Saves user's uid, email, displayName and photoURL
  /**************************************************************/
function fbR_procReadAdmin(_path, _key, _snapshot, _save, _error){
  console.log('%cfb_procReadAdmin: path= '+_path+
             ' key= '+_key, 'color: brown;');

  if(_error == null){
    dbData = snapshot.val();
    if(dbData != 'OK'){
      readStatus = 'OK';
    }
    else{
      readStatus = 'no record';
    }
  }
  else{
    readStatus = 'error';
    console.log('%c' +_error, 'color: red;');
  }
}

  /**************************************************************/
  // fbR_writeRecfbKey()
  // Input:  User's imformation
  // Return: Saves user's uid, email, displayName and photoURL
  /**************************************************************/
function fbR_writeRecfbKey(_path, _key, _data){
  console.log('%cfb_writeRecfbKey: path= '+_path+' key= '+_key+
             ' data= '+_data.displayName+ '/'+_data.score,
             'color: brown;');

  writeStatus = 'waiting';
  var newRecRef = firebase.database().ref(_path).push(_data,
  function(error){
    if(error){
      writeStatus = 'failed...';
      console.log('fbR_writeRecfbKey: callback - writeStatus of '+ writeStatus);
      console.log(error);
    }
    else{
      writeStatus = 'OK';
      var newKey = newRecRef.key;
      console.log('fbR_writeRecfbKey: key= '+ newKey +
                 ' callback - writeStatus of '+writeStatus);
    }
  });

  console.log('fbR_writeRecfbKey: exit with writeStatus of ' + writeStatus);
}


function fbR_procWriteUD(_error){
  console.log('%cfbR_procWriteUD: ', 'color: brown;');
  if(_error == null){
    writeStatus = 'OK';
    window.location = "/html/gs.html";
  } else {
    console.error(_error);
    alert("write error, see console log for details");
  }
}

  /**************************************************************/
  // fbR_procReadLobbyGs(_path, _snapshot, _save, _error)
  // Input:  User's imform_path, _snapshot, _save, _errortion
  // Return: Saves user's uid, email, displayName and photoURL
  /**************************************************************/
function fbR_procReadLobbyGs(_path, _snapshot, _save, _error){
  console.log('%c fbR_procReadLobbyGs: path='+_path,
             'color: brown');

  if(_error == null){
    dbData = _snapshot.val();
    if(dbData == null){
      readStatus = 'no records';
    }
    else{
      readStatus = 'OK';
      var dbKeys = Object.keys(dbData);
      console.log(dbKeys);
      for(i=0; i < dbKeys.length; i++){
        var k = dbKeys[i];
        _save.push({
          score: dbData[k].score,
          gameName: dbData[k].gameName,
        });
      }
    }
  }
  else{
    // There was an error
    readStatus = 'error';
    console.log('%c'+_error, 'color: red;');
  }
}

  /**************************************************************/
  // fbR_lobbyData(data)
  // Input:  User's imform_path, _snapshot, _save, _errortion
  // Return: Saves user's uid, email, displayName and photoURL
  /**************************************************************/

function fbR_lobbyData(data){
    console.log('%cfbR_lobbyData: ', 'color: blue;');
    
    var tabledata = document.querySelector(".data_lobby");
    var objectDataString = JSON.stringify(data);
    var objectdata = JSON.parse(objectDataString);
    var dataArrayOne = Array.isArray(data) ? data : [data];
    joined = true;
    _key = userDetails.uid;
    
    var tester = Array.isArray(data) ? data : data;
    var testering = Object.keys(data).map(key => ({ name: key, ...data[key] }));
    console.log(testering);
    
    var dataArray = Object.keys(data).map(key => ({ name: key, ...data[key] }));
    var elements = "";
    
    dataArray.forEach(record => {
        elements += `
            <tr>
                <td>${record.name}</td>
                <td>
                    <button onclick="fb_joinLobby(data, joined, _key)">Join</button>
                </td>
            </tr>
        `;
    });
    
    tabledata.innerHTML = elements;
}