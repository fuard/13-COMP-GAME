/**************************************************************/
// fb_io.js
// Skeleton written by ???   2023
// v1 firebase DB testing write AND read to firebase
// v2 add Google login
// v2 use pop up for login
// v3 add console.logs
/**************************************************************/
MODULENAME = "fb_io.js";
console.log('%c' + MODULENAME + ': ', 'color: blue;');

/**************************************************************/
// fb_login(_save, _procFunc)
// Called by setup
// Login to Firebase
// Input:  object for login data to save to
// Return: n/a
/**************************************************************/
function fb_login(_save, _procFunc) {
  console.log('%cfb_login: ', 'color: brown;');
  firebase.auth().onAuthStateChanged(newLogin);

  /*-----------------------------------------*/
  // newLogin(user)
  /*-----------------------------------------*/
  function newLogin(_user) {
    let loginStatus; // Declare the variable here

    if (_user) {
      // User is signed in, check if they are registered
      var uid = _user.uid;
      console.log('fb_login: User is signed in with UID: ' + uid);
      var userRef = firebase.database().ref('users/' + uid);

      userRef.once('value').then(function(snapshot) {
        if (snapshot.exists()) {
          console.log('fb_login: User is registered.');
          // User is registered, proceed to the game
          loginStatus = 'logged in';
          _procFunc(loginStatus, _user, _save);
          window.location = "/html/gs.html";
        } else {
          console.log('fb_login: User is not registered.');
          // User is not registered, redirect to registration
          loginStatus = 'not registered';
          _procFunc(loginStatus, _user, _save);
          window.location = "/html/registration.html";
        }
        console.log('fb_login: status = ' + loginStatus);
      }).catch(function(error) {
        console.log('%cfb_login: Error checking registration status - ' + error.message, 'color: red;');
      });
    } else {
      // User not logged in, so redirect to Google login
      loginStatus = 'logged out';
      console.log('fb_login: status = ' + loginStatus);

      var provider = new firebase.auth.GoogleAuthProvider();
      firebase.auth().signInWithPopup(provider).then(function(result) {
        loginStatus = 'logged in via popup';
        _procFunc(loginStatus, result.user, _save);
        console.log('fb_login: status = ' + loginStatus);
      })
      // Catch errors
      .catch(function(error) {
        if (error) {
          loginStatus = 'failed';
          console.log('%cfb_login: ' + error.code + ', ' + error.message, 'color: red;');
          console.log('fb_login: status = ' + loginStatus);
        }
      });
    }
  }
}
/**************************************************************/
// fb_logout()
// Logout of Firebase
// Input:  n/a
// Return: n/a
/**************************************************************/
function fb_logout() {
  console.log('%cfb_logout: ', 'color: brown;');
  firebase.auth().signOut();
  window.location = "/index.html";
}

/**************************************************************/
// fb_writeRec(_path, _key, _data)
// Write a specific record & key to the DB
// Input:  path to write to, the key and the data to write
// Return: 
/**************************************************************/
function fb_writeRec(_path, _key, _data) { 
  console.log('%cfb_WriteRec: path= ' + _path + '  key= ' + _key +
              '  data= ' + _data.displayName + '/' + _data.score, 
              'color: brown;');

  writeStatus = "Waiting";
  firebase.database().ref(_path + '/' + _key).set(_data, 
  function (error){
    if(error){
      writeStatus = "Fail";
      console.log(error)
  } else {
      writeStatus = "Ok"
      window.location = "gs.html";
    }
  });
  console.log("fb_writeRec: exit");
}

/**************************************************************/
// fb_writeRec(_path, _key, _data)
// Write a specific record & key to the DB
// Input:  path to write to, the key and the data to write
// Return: 
/**************************************************************/
function fb_writeRecPong(_path, _key, _data) { 
  console.log('%cfb_WriteRec: path= ' + _path + '  key= ' + _key +
              '  data= ' + _data.displayName + '/' + _data.score, 
              'color: brown;');

  writeStatus = "Waiting";
  firebase.database().ref(_path + '/' + _key).set(_data, 
  function (error){
    if(error){
      writeStatus = "Fail";
      console.log(error)
  } else {
      writeStatus = "Ok"
    }
  });
  console.log("fb_writeRec: exit");
}

/**************************************************************/
// fb_readAll(_path, _data)
// Read all DB records for the path
// Input:  path to read from and where to save the data
// Return:
/**************************************************************/
function fb_readAll(_path, _procFunc) {
//function fb_readAll(_path, _data) {
  console.log('%cfb_readAll: path= ' + _path, 'color: brown;');

  readStatus = "Waiting";
  firebase.database().ref(_path).once("value", gotRecord, readErr);

  function gotRecord (snapshot){
    _procFunc (_path, snapshot, null);
  }

  function readErr (_error){
    _procFunc (_path, null, _error);
  }
}

/**************************************************************/
// fb_readRec(_path, _key, _data)
// Read a specific DB record
// Input:  path & key of record to read and where to save the data
// Return:  
/**************************************************************/
function fb_readRec(_path, _key, _data, _processData) {	
  console.log('%cfb_readRec: path= ' + _path + 
              '  key= ' + _key, 'color: brown;');

  readStatus = "Waiting";
  firebase.database().ref(_path + '/' + _key).once("value", gotRecord, readErr);
 
  function gotRecord(snapshot){
    if(snapshot.val() == null){
      readStatus = "No record";
    } else {
      readStatus = "Ok";
        
    }
    _processData(_path, _key, snapshot, _data);
  }

  function readErr(error){
    readStatus = "Fail";
    _processData(_path, _key, null, _data, error);
  }
}

/**************************************************************/
// fb_readOn(_path, _key, _data, _processData)
// Read a DB record, general use
// Input:  path & key of record to read and where to save the data
// Return:  
/**************************************************************/
function fb_readOn(_path, _key, _data, _processData) {	
  console.log('%c fb_readOn: path= ' + _path + 
              '  key= ' + _key, 'color: brown;');

  readStatus = "Waiting";
  firebase.database().ref(_path + '/' + 'gn'+ '/' + _key).on("value", gotRecord, readErr);
 
  function gotRecord(snapshot){
    if(snapshot.val() == null){
      readStatus = "No record";
    } else {
      readStatus = "Ok";
        
    }
    _processData(_path, _key, snapshot, _data);
  }

  function readErr(error){
    readStatus = "Fail";
    _processData(_path, _key, null, _data, error);
  }
}

/**************************************************************/
// fb_readOff(_path, _key, _data, _processData)
// Read a DB record, general use
// Input:  path & key of record to read and where to save the data
// Return:  
/**************************************************************/
function fb_readOff(_path, _key, _data, _processData) {	
  console.log('%c fb_readOff: path= ' + _path + 
              '  key= ' + _key, 'color: green;');

  readStatus = "Waiting";
  firebase.database().ref(_path + '/' + _key).off();

  function readErr(error){
    readStatus = "Fail";
    _processData(_path, _key, null, _data, error);
  }
}


/**************************************************************/
// fb_writeRecLobby(_path, _key, _data)
// Write a record & key to the DB, it's generic 
// Input:  path to write to, the key and the data to write
// Return: 
/**************************************************************/
function fb_writeRecLobby(_path, _key, _data) { 
  console.log('%c fb_writeRecLobby: path= ' + _path + 
              '  key= ' + _key, 'color: brown;');

  writeStatus = "Waiting";
  firebase.database().ref(_path + '/' + _key).set(_data, 
  function (error){
    if(error){
      writeStatus = "Fail";
      console.log(error)
  } else {
      writeStatus = "Ok";
      fbR_writeLobby(_path, _snapshot, _error);
    }
  });
  console.log("fb_writeRec: exit");
}

/**************************************************************/
// fb_buildLobbyTable()
// Retrieves lobby data from Firebase, processes it, and builds a lobby table.
// Input:  path to write to, the key and the data to write
// Return: 
/**************************************************************/
function fb_buildLobbyTable(){
    console.log('%cfb_buildLobbyTable: ', 'color: brown;');
    
    var user_ref = database.ref('lobby/gn/');
    user_ref.on('value', function(snapshot){
        data = snapshot.val()
        fbR_lobbyData(data); //Call a function to process the data
    });
}

/**************************************************************/
// fb_createLobby()
// Retrieves lobby data from Firebase, processes it, and builds a lobby table.
// Input:  path to write to, the key and the data to write
// Return: 
/**************************************************************/
function fb_createLobby(){
    console.log('%cfb_buildLobbyTable: ', 'color: brown;');
    
    firebase.database().ref('lobby' + '/' + 'gn' + '/' + _key + '/').set(data, 
      function (error){
        if(error){
          writeStatus = "Fail";
          console.log(error)
      } else {
          writeStatus = "Ok";
          fb_updateGameStorage(_key)
          fbR_createLobby();
        }
      });
      console.log("fb_createLobby: exit");
}


/**************************************************************/
// fb_buildLobbyTable()
// Retrieves lobby data from Firebase, processes it, and builds a lobby table.
// Input:  path to write to, the key and the data to write
// Return: 
/**************************************************************/

function fb_joinLobby(data, joined, _key) {
    console.log('%cfb_joinLobby: ', 'color: brown;');

    if (userDetails.uid == _key) {
        console.log('Cannot join your own lobby');
        alert('Cannot join your own lobby');
        return;
    }

    // Save _key in session storage with the name 'lobbyName'
    sessionStorage.setItem('lobbyName', _key);

    firebase.database().ref('lobby' + '/' + 'gn' + '/' + _key + '/' + 'p2join').set(joined);
    firebase.database().ref('lobby' + '/' + 'gn' + '/' + _key + '/' + 'p2uid').set(userDetails.uid);

    console.log(_key);
    window.location = "/game/guess_game.html" 
}

// Function to retrieve lobbyName from session storage
var lobbyName;
function getLobbyName() {
    console.log('%cgetLobbyName: ', 'color: brown;');
    lobbyName = sessionStorage.getItem('lobbyName');
    return lobbyName;
}
/**************************************************************/
// fb_buildLobbyTable()
// Retrieves lobby data from Firebase, processes it, and builds a lobby table.
// Input:  path to write to, the key and the data to write
// Return: 
/**************************************************************/
function fb_buildLeaderBoardTable(){
    console.log('%cfb_buildLobbyTable: ', 'color: brown;');
    
    var user_ref = database.ref('lobby/gn/');
    user_ref.on('value', function(snapshot){
        data = snapshot.val()
        fbR_lobbyData(data); //Call a function to process the data
    });
}

/**************************************************************/
// fb_buildLobbyTable()
// Retrieves lobby data from Firebase, processes it, and builds a lobby table.
// Input:  path to write to, the key and the data to write
// Return: 
/**************************************************************/
        function updateLeaderboard() {
            console.log('%cupdateLeaderboard: ', 'color: brown;');

            // Reference to the userDetails path in the database
            var userDetailsRef = firebase.database().ref('userDetails');

            // Read the data from the userDetails path
            userDetailsRef.once('value', function(snapshot) {
                var users = [];

                // Loop through each user and get their details
                snapshot.forEach(function(childSnapshot) {
                    var user = childSnapshot.val();
                    user.uid = childSnapshot.key; // Store the UID in the user object
                    users.push(user);
                });

                // Sort users by gNwins in descending order
                users.sort(function(a, b) {
                    return (b.gNwins || 0) - (a.gNwins || 0);
                });

                // Get the top 5 users
                var topUsers = users.slice(0, 5);

                // Update the leaderboard table
                var leaderboardTable = document.getElementById('leaderboardTable').getElementsByTagName('tbody')[0];
                leaderboardTable.innerHTML = ''; // Clear any existing rows

                topUsers.forEach(function(user, index) {
                    var row = leaderboardTable.insertRow();
                    var cell1 = row.insertCell(0);
                    var cell2 = row.insertCell(1);
                    var cell3 = row.insertCell(2);
                    cell1.innerHTML = index + 1; // Rank
                    cell2.innerHTML = user.displayName || 'Anonymous'; // User's name
                    cell3.innerHTML = user.gNwins || 0; // User's wins
                });
            });
        }
/**************************************************************/
//    END OF MODULE
/**************************************************************/