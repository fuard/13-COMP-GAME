/*------------------------------------------------------------*/
// reg_manager.js
//
// Get & validate user input from form AND if OK write to DB
// Written by Mr Bob 2020
// v01 Initial code
// v02 Include reg_getFormItemValue function in reg_manager.js 
// v03 Add reg_prep function
// v04 Add conversion from string to number for numeric feilds
// v05 Cut down version
// v06 Check if form passed html validation
// v07 Alter to be used as standalone html file
/*------------------------------------------------------------*/

/*************************************************************          //<=======
  TO IMPLIMENT THE REGISTRATION FEATURE:                                //<=======
    1. Create a ???????.js module in your project &                     //<=======
       Copy the contents of this file into it.                          //<=======
       Taylor your ???????.js to fit your program code by looking       //<=======
         at lines ending with  //<=======                               //<=======
         
    2. Create a new .css file for your registration page.               //<=======
       Copy the contents of this project's style.css file into it.      //<=======
       
    3. Create your folder structure for your projects images.           //<=======
       Download this project to your computer.                          //<=======
       Extract all the files from the zipped folder.                    //<=======
       Upload all the images to you project's images folder.            //<=======
       
    3. Create a new .html file.                                         //<=======
       Copy the contents of this project's index.html file into it.     //<=======
       Alter the link to point to your new .css file.                   //<=======
       Alter the link to point to your new ???????.js file.             //<=======
       Alter any links to point to your project's folder structure.     //<=======
       Add any required <script src=''> tags to your code.              //<=======
*************************************************************/          //<=======
MODULENAME = "reg_manager.js";
console.log('%c' + MODULENAME, 'color: blue');

/*------------------------------------------------------------*/
// These two lines need to be executed only after the                   //<=======
//  registration page is displayed                                      //<=======
// Save name & email into the form
// ENSURE THE OBJECT NAME IS CORRECT; its currently details    //<=======
function reg_load(){
  document.getElementById("p_regName").innerHTML  = userDetails.displayName          //<=======
  document.getElementById("p_regEmail").innerHTML = userDetails.email
  
}
         //<=======

/*------------------------------------------------------------*/
// reg_regDetailsEntered()
// Input event; called when user clicks ?????????? button               //<========
// Write user's details to DB
// Input:   
// Return:
/*------------------------------------------------------------*/
function reg_regDetailsEntered() {
  console.log('%creg_regDetailsEntered: ', 'color: brown;');
     
  // Save player1's details from the form into your details object
  //  ENSURE THE OBJECT NAME THE PROGRAM SAVES TO IS CORRECT; 
  //    its currently details                                           //<=======
  userDetails.gameName     =        reg_getFormItemValue("f_reg", 0);       //<=======
  userDetails.phone        = Number(reg_getFormItemValue("f_reg", 1));      //<=======
  userDetails.gender       =        reg_getFormItemValue("f_reg", 2);       //<=======
  userDetails.age          = Number(reg_getFormItemValue("f_reg", 3));      //<=======
  userDetails.gNwins       = Number(null)                                   //<=======
  userDetails.gNloses      = Number(null)                                   //<=======
  
  console.log("reg_regDetailsEntered: form passed html validation - " +
            document.getElementById('f_reg').checkValidity()); 

  // Only write record to DB if all the fom's input passed html validation
  if (document.getElementById('f_reg').checkValidity()) {
   fb_writeRec(DETAILS, userDetails.uid, userDetails, fbR_procWriteUD);
  }
}

/*------------------------------------------------------------*/
// reg_getFormItemValue(_elementId, _item)
// Called by reg_regDetailsEntered
// Returns the value of the form's item
// Input:  element id & form item number
// Return: form item's value
/*------------------------------------------------------------*/
function reg_getFormItemValue(_elementId, _item) {
  console.log('%creg_getFormItemValue: _elementId=' + _elementId + 
              ',  _item= ' + _item, 'color: brown;');
    
  return document.getElementById(_elementId).elements.item(_item).value;
}

/*------------------------------------------------------------*/
//    END OF PROG
/*------------------------------------------------------------*/