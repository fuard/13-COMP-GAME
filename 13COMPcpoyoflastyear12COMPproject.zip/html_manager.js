console.log("%c html_manager.js",'color:blue;');

function html_load(){
  console.log("%c html_load",'color:brown;');
  fbR_initialise();
  
  userDetails.uid = sessionStorage.getItem("uid");
  userDetails.email = sessionStorage.getItem("email");
  userDetails.displayName = sessionStorage.getItem("displayName");
  userDetails.photoURL = sessionStorage.getItem("photoURL");
  userDetails.gameName = sessionStorage.getItem("gameName");
}

function html_check_ka_score(){
  console.log("html_check_ka_score");

  if(score > highScore.score){
    highScore.score = score;
    fb_writeRec("userScores/ka", userDetails.uid, highScore);
  }
}

function html_check_wm_score(){
  console.log("html_check_wm_score");

  if(score > highScore.score){
    highScore.score = score;
    fb_writeRecPong("userScores/wm", userDetails.uid, highScore);
  }
}