console.log("%c html_manager.js",'color:blue;');

function html_load(){
  console.log("%c html_load",'color:brown;');
  fbR_initialise();
  
  userDetails.uid = sessionStorage.getItem("uid");
  userDetails.email = sessionStorage.getItem("email");
  userDetails.displayName = sessionStorage.getItem("displayName");
  userDetails.photoURL = sessionStorage.getItem("photoURL");
  userDetails.gameName = sessionStorage.getItem("gameName");
}

function html_check_ka_score(){
  console.log("html_check_ka_score");

  if(score > highScore.score){
    highScore.score = score;
    fb_writeRec("userScores/ka", userDetails.uid, highScore);
  }
}

function html_check_wm_score(){
  console.log("html_check_wm_score");

  if(score > highScore.score){
    highScore.score = score;
    fb_writeRecPong("userScores/wm", userDetails.uid, highScore);
  }
}

var lobbyName;
function gameLoad(_key){
    sessionStorage.setItem('lobbyName', _key);
    lobbyName = sessionStorage.getItem("lobbyName");
}

var admin_list = []; // Global array to store the admin names

function readAdminRecord() {
    console.log('%creadAdminRecord: ', 'color: brown;');

    // Reference to the 'admin' record in the database
    var adminRef = firebase.database().ref('admin');

    // Read the data from the 'admin' record
    adminRef.once('value', function(snapshot) {
        snapshot.forEach(function(childSnapshot) {
            var name = childSnapshot.key; // Get the key of each child under 'admin'
            admin_list.push(name); // Add the name to the admin_list array
        });

        console.log('Admin Names:', admin_list); // Verify the names are stored correctly
        checkAdminAccess();
    });
}

function checkAdminAccess() {
    console.log('%ccheckAdminAccess: ', 'color: brown;');
    var userUid = userDetails.uid;
    x = document.getElementById('adminButton')
    if (admin_list.includes(userUid)) {
        x.style.display = "block" // Show the button
    } else {
        x.style.display = "none"
    }
}