// Generate a random number
let x = Math.floor((Math.random() * 10) + 1);
console.log("Random number:", x);
window.addEventListener('load', function() {
    console.log('Lobby Name from guess_game.js:', lobbyName); // This should correctly log the lobby name
    // You can now use lobbyName in this script
});

// Process guess submission
function g_submitProc() {
    console.log('%cg_submitProc: ', 'color: blue;');
    
    let playerNumber = document.querySelector(".text_here").value;
    console.log("Player's guess:", String(playerNumber));

    if (parseInt(playerNumber) === x) {
        alert("Hooray you're right!");
        winner();
    } else if (parseInt(playerNumber) > 10 || parseInt(playerNumber) < 1) {
        alert("Guess between 1-10!!");
    } else {
        alert("Shame, you're wrong!");
    }
}

var p2uid;
function readP2uidRecord() {
    console.log('%creadP2uidRecord: ', 'color: brown;');

    // Reference to the specific path in the database
    var p2uidRef = firebase.database().ref('lobby/gn/' + lobbyName + '/p2uid');

    // Read the data from the specified path
    p2uidRef.once('value', function(snapshot) {
        p2uid = snapshot.val(); // Get the value of p2uid
        console.log('p2uid:', p2uid); // Verify the p2uid value is stored correctly
    });
}

function winner(){
    console.log('%cwinner: ', 'color: brown;');
    if(lobbyName == userDetails.uid){
        console.log('%cp1 wins: ', 'color: brown;');
        // Reference to the user's gNwins path
        var gNwinsRef = firebase.database().ref('userDetails/' + userDetails.uid + '/gNwins');
        // Reference to the p2uid's gNloses path
        var gNlosesRef = firebase.database().ref('userDetails/' + p2uid + '/gNloses');

        // Increment the gNwins score
        gNwinsRef.once('value', function(snapshot) {
            var currentWins = snapshot.val() || 0;
            gNwinsRef.set(currentWins + 1);
        });

        // Increment the gNloses score
        gNlosesRef.once('value', function(snapshot) {
            var currentLoses = snapshot.val() || 0;
            gNlosesRef.set(currentLoses + 1);
        });

    } else if(lobbyName != userDetails.uid){
        console.log('%cp2 wins: ', 'color: brown;');
        // Reference to the user's gNwins path
        var gNwinsRef = firebase.database().ref('userDetails/' + userDetails.uid + '/gNwins');
        // Reference to the p2uid's gNloses path
        var gNlosesRef = firebase.database().ref('userDetails/' + lobbyName + '/gNloses');

        // Increment the gNwins score
        gNwinsRef.once('value', function(snapshot) {
            var currentWins = snapshot.val() || 0;
            gNwinsRef.set(currentWins + 1);
        });

        // Increment the gNloses score
        gNlosesRef.once('value', function(snapshot) {
            var currentLoses = snapshot.val() || 0;
            gNlosesRef.set(currentLoses + 1);
        });
    }
}