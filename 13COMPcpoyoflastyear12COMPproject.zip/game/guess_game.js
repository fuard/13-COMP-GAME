let playerNumber;
let x = Math.floor((Math.random() * 10) + 1);
console.log("Random number:", x);

function g_submitProc(){
    console.log('%cg_submitProc: ', 'color: blue;');
    
    playerNumber = document.getElementById("submit_button").value;
    console.log("Player's guess:", String(playerNumber));

    if (parseInt(playerNumber) === x){
        alert("Hooray you're right!");
    }
    else {
        alert("Shame! You're wrong");
    }
}