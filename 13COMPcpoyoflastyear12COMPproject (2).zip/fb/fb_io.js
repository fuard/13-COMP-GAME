/**************************************************************/
// fb_io.js
// Skeleton written by ???   2023
// v1 firebase DB testing write AND read to firebase
// v2 add Google login
// v2 use pop up for login
// v3 add console.logs
/**************************************************************/
MODULENAME = "fb_io.js";
console.log('%c' + MODULENAME + ': ', 'color: blue;');

/**************************************************************/
// fb_login(_save, _procFunc)
// Called by setup
// Login to Firebase
// Input:  object for login data to save to
// Return: n/a
/**************************************************************/
function fb_login(_save, _procFunc) {
  console.log('%cfb_login: ', 'color: brown;');
  firebase.auth().onAuthStateChanged(newLogin);

  /*-----------------------------------------*/
  // newLogin(user)
  /*-----------------------------------------*/
  function newLogin(_user) {
    if (_user) {
      // User is signed in, check if they are registered
      var uid = _user.uid;
      var userRef = firebase.database().ref('users/' + uid);

      userRef.once('value').then(function(snapshot) {
        if (snapshot.exists()) {
          // User is registered, proceed to the game
          loginStatus = 'logged in';
          _procFunc(loginStatus, _user, _save);
          window.location = "/html/gs.html";
        } else {
          // User is not registered, redirect to registration
          loginStatus = 'not registered';
          _procFunc(loginStatus, _user, _save);
          window.location = "/html/registration.html";
        }
      }).catch(function(error) {
        console.log('%cfb_login: Error checking registration status - ' + error.message, 'color: red;');
      });
    } 
    else {
      // User not logged in, so redirect to Google login
      loginStatus = 'logged out';
      
      var provider = new firebase.auth.GoogleAuthProvider();
      firebase.auth().signInWithPopup(provider).then(function(result) {
        loginStatus = 'logged in via popup';
        _procFunc(loginStatus, result.user, _save);
      })
      // Catch errors
      .catch(function(error) {
        if (error) {
          loginStatus = 'failed';
          console.log('%cfb_login: ' + error.code + ', ' + error.message, 'color: red;');
        }
      });
    }
    console.log('fb_login: status = ' + loginStatus);
  }
}


/**************************************************************/
// fb_logout()
// Logout of Firebase
// Input:  n/a
// Return: n/a
/**************************************************************/
function fb_logout() {
  console.log('%cfb_logout: ', 'color: brown;');
  firebase.auth().signOut();
}

/**************************************************************/
// fb_writeRec(_path, _key, _data)
// Write a specific record & key to the DB
// Input:  path to write to, the key and the data to write
// Return: 
/**************************************************************/
function fb_writeRec(_path, _key, _data) { 
  console.log('%cfb_WriteRec: path= ' + _path + '  key= ' + _key +
              '  data= ' + _data.displayName + '/' + _data.score, 
              'color: brown;');

  writeStatus = "Waiting";
  firebase.database().ref(_path + '/' + _key).set(_data, 
  function (error){
    if(error){
      writeStatus = "Fail";
      console.log(error)
  } else {
      writeStatus = "Ok"
      window.location = "gs.html";
    }
  });
  console.log("fb_writeRec: exit");
}

/**************************************************************/
// fb_writeRec(_path, _key, _data)
// Write a specific record & key to the DB
// Input:  path to write to, the key and the data to write
// Return: 
/**************************************************************/
function fb_writeRecPong(_path, _key, _data) { 
  console.log('%cfb_WriteRec: path= ' + _path + '  key= ' + _key +
              '  data= ' + _data.displayName + '/' + _data.score, 
              'color: brown;');

  writeStatus = "Waiting";
  firebase.database().ref(_path + '/' + _key).set(_data, 
  function (error){
    if(error){
      writeStatus = "Fail";
      console.log(error)
  } else {
      writeStatus = "Ok"
    }
  });
  console.log("fb_writeRec: exit");
}

/**************************************************************/
// fb_readAll(_path, _data)
// Read all DB records for the path
// Input:  path to read from and where to save the data
// Return:
/**************************************************************/
function fb_readAll(_path, _procFunc) {
//function fb_readAll(_path, _data) {
  console.log('%cfb_readAll: path= ' + _path, 'color: brown;');

  readStatus = "Waiting";
  firebase.database().ref(_path).once("value", gotRecord, readErr);

  function gotRecord (snapshot){
    _procFunc (_path, snapshot, null);
  }

  function readErr (_error){
    _procFunc (_path, null, _error);
  }
}

/**************************************************************/
// fb_readRec(_path, _key, _data)
// Read a specific DB record
// Input:  path & key of record to read and where to save the data
// Return:  
/**************************************************************/
function fb_readRec(_path, _key, _data, _processData) {	
  console.log('%cfb_readRec: path= ' + _path + 
              '  key= ' + _key, 'color: brown;');

  readStatus = "Waiting";
  firebase.database().ref(_path + '/' + _key).once("value", gotRecord, readErr);
 
  function gotRecord(snapshot){
    if(snapshot.val() == null){
      readStatus = "No record";
    } else {
      readStatus = "Ok";
        
    }
    _processData(_path, _key, snapshot, _data);
  }

  function readErr(error){
    readStatus = "Fail";
    _processData(_path, _key, null, _data, error);
  }
}

/**************************************************************/
// fb_readOn(_path, _key, _data, _processData)
// Read a DB record, general use
// Input:  path & key of record to read and where to save the data
// Return:  
/**************************************************************/
function fb_readOn(_path, _key, _data, _processData) {	
  console.log('%c fb_readOn: path= ' + _path + 
              '  key= ' + _key, 'color: brown;');

  readStatus = "Waiting";
  firebase.database().ref(_path + '/' + 'gn'+ '/' + _key).on("value", gotRecord, readErr);
 
  function gotRecord(snapshot){
    if(snapshot.val() == null){
      readStatus = "No record";
    } else {
      readStatus = "Ok";
        
    }
    _processData(_path, _key, snapshot, _data);
  }

  function readErr(error){
    readStatus = "Fail";
    _processData(_path, _key, null, _data, error);
  }
}

/**************************************************************/
// fb_readOn()
// Read a specific DB record
// Input:  path & key of record to read and where to save the data
// Return:  
/**************************************************************/
/*function readOn(_path, _key) { // reads the database for the pong high score
  console.log('%c fb_readon, path/user: ' + _path + '/' + _key,'color: purple;');
  firebase.database().ref(_path + '/' + _key).on('value', _readUID);
  console.log('%cfb_readon', 'color: green;');
 
  function _readUID(snapshot) {
     dbData = snapshot.val();
        if (dbData === null) {
        console.error('fb_readon: path/user:  ' + _path + '/' + _key +
        " no record");
    }
    else {
      if(dbData == true) {
          console.log('fb_readon: path/user:  ' + _path + '/' + _key +
          " player 2 joined");
          // cancel the readon here
          database.ref(_path + '/' + _key).off();
      }
      else {
          console.log('fb_readon: path/user:  ' + _path + '/' + _key +
          " still waiting");
        }
    }
}
};*/

/*var _data.createAt = firebase.database.ServerValue.TIMESTAMP;
_data.online = true;*/


/**************************************************************/
// fb_readOff(_path, _key, _data, _processData)
// Read a DB record, general use
// Input:  path & key of record to read and where to save the data
// Return:  
/**************************************************************/
function fb_readOff(_path, _key, _data, _processData) {	
  console.log('%c fb_readOff: path= ' + _path + 
              '  key= ' + _key, 'color: green;');

  readStatus = "Waiting";
  firebase.database().ref(_path + '/' + _key).off();

  function readErr(error){
    readStatus = "Fail";
    _processData(_path, _key, null, _data, error);
  }
}


/**************************************************************/
// fb_writeRecLobby(_path, _key, _data)
// Write a record & key to the DB, it's generic 
// Input:  path to write to, the key and the data to write
// Return: 
/**************************************************************/
function fb_writeRecLobby(_path, _key, _data) { 
  console.log('%c fb_writeRecLobby: path= ' + _path + 
              '  key= ' + _key, 'color: brown;');

  writeStatus = "Waiting";
  firebase.database().ref(_path + '/' + _key).set(_data, 
  function (error){
    if(error){
      writeStatus = "Fail";
      console.log(error)
  } else {
      writeStatus = "Ok";
      fbR_writeLobby(_path, _snapshot, _error);
    }
  });
  console.log("fb_writeRec: exit");
}

/**************************************************************/
// fb_buildLobbyTable()
// Retrieves lobby data from Firebase, processes it, and builds a lobby table.
// Input:  path to write to, the key and the data to write
// Return: 
/**************************************************************/
function fb_buildLobbyTable(){
    console.log('%cfb_buildLobbyTable: ', 'color: brown;');
    
    var user_ref = database.ref('lobby/gn/');
    user_ref.on('value', function(snapshot){
        data = snapshot.val()
        fbR_lobbyData(data); //Call a function to process the data
    });
}

/**************************************************************/
// fb_createLobby()
// Retrieves lobby data from Firebase, processes it, and builds a lobby table.
// Input:  path to write to, the key and the data to write
// Return: 
/**************************************************************/
function fb_createLobby(){
    console.log('%cfb_buildLobbyTable: ', 'color: brown;');
    
    firebase.database().ref('lobby' + '/' + 'gn' + '/' + _key + '/').set(data, 
      function (error){
        if(error){
          writeStatus = "Fail";
          console.log(error)
      } else {
          writeStatus = "Ok";
          fbR_createLobby();
        }
      });
      console.log("fb_createLobby: exit");
}

/**************************************************************/
// fb_createLobby()
// Retrieves lobby data from Firebase, processes it, and builds a lobby table.
// Input:  path to write to, the key and the data to write
// Return: 
/**************************************************************/
function fb_updateGameStorage(_key){
    console.log('%cfb_updateGameStorage: ', 'color: brown;');
    sessionStorage.setItem("lobbyName", _key);
    lobbyName = sessionStorage.getItem("lobbyName");
}
/**************************************************************/
// fb_buildLobbyTable()
// Retrieves lobby data from Firebase, processes it, and builds a lobby table.
// Input:  path to write to, the key and the data to write
// Return: 
/**************************************************************/

function fb_joinLobby(data, joined, _key) {
    console.log('%cfb_joinLobby: ', 'color: brown;');
    
    if (userDetails.uid == _key) {
        console.log('Cannot join your own lobby');
        alert('Cannot join your own lobby');
        return;
    }
    
    firebase.database().ref('lobby' + '/' + 'gn' + '/' + _key + '/' + 'p2join').set(joined);
    firebase.database().ref('lobby' + '/' + 'gn' + '/' + _key + '/' + 'p2uid').set(userDetails.uid);

    console.log(_key);
    fb_updateGameStorage(_key);
    window.location = "/game/guess_game.html" 
}
/**************************************************************/
// fb_buildLobbyTable()
// Retrieves lobby data from Firebase, processes it, and builds a lobby table.
// Input:  path to write to, the key and the data to write
// Return: 
/**************************************************************/
function fb_buildLeaderBoardTable(){
    console.log('%cfb_buildLobbyTable: ', 'color: brown;');
    
    var user_ref = database.ref('lobby/gn/');
    user_ref.on('value', function(snapshot){
        data = snapshot.val()
        fbR_lobbyData(data); //Call a function to process the data
    });
}
/**************************************************************/
//    END OF MODULE
/**************************************************************/