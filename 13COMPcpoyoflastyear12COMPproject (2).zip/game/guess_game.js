// Utility function to get query parameter value
function getQueryParam(param) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(param);
}

// Get lobbyName from URL
const lobbyName = getQueryParam('lobbyName');
if (!lobbyName) {
    console.error('lobbyName is not defined');
}

// Firebase read function
function fbg_readRec(_key) {
    console.log('%cfb_readRec: path= ' + 'lobby' + '/' + 'gn' + _key, 'color: brown;');

    readStatus = "Waiting";
    firebase.database().ref('lobby' + '/' + 'gn'+ '/' + _key).once("value", gotRecord, readErr);

    function gotRecord(snapshot) {
        if (snapshot.val() == null) {
            readStatus = "No record";
        } else {
            readStatus = "Ok";
        }
        _processData(('lobby' + '/' + 'gn'+ '/' + _key), _key, snapshot, _data);
    }

    function readErr(error) {
        readStatus = "Fail";
        _processData(('lobby' + '/' + 'gn'+ '/' + _key), _key, null, _data, error);
    }
}

// Generate a random number
let x = Math.floor((Math.random() * 10) + 1);
console.log("Random number:", x);

// Process guess submission
function g_submitProc() {
    console.log('%cg_submitProc: ', 'color: blue;');
    
    let playerNumber = document.querySelector(".text_here").value;
    console.log("Player's guess:", String(playerNumber));

    if (parseInt(playerNumber) === x) {
        alert("Hooray you're right!");
        winner();
    } else if (parseInt(playerNumber) > 10 || parseInt(playerNumber) < 1) {
        alert("Guess between 1-10!!");
    } else {
        alert("Shame, you're wrong!");
    }
}

// Function to handle a winning guess
function winner() {
    if (!lobbyName) {
        console.error('lobbyName is not defined');
        return;
    }

    fb_readRec('lobby/gn', lobbyName, null, function(_path, _key, snapshot1) {
        fb_readRec('lobby/gn', userDetails.uid, null, function(_path, _key, snapshot2) {
            const data1 = snapshot1.val() || { p1wins: 0, p1loses: 0 };
            const data2 = snapshot2.val() || { p1wins: 0, p1loses: 0 };
            
            data1.p1wins = (data1.p1wins || 0) + 1;
            data2.p1loses = (data2.p1loses || 0) + 1;

            firebase.database().ref('lobby/gn/' + lobbyName).update({ p1wins: data1.p1wins, p1loses: data1.p1loses });

            alert("Player 1 wins! Player 2 loses!");
        });
    });
}